/**
 * This file is for implementation of mimpirun program.
 * */


#include "mimpi_common.h" 
#include "channel.h"

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h> // For O_* constants.
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h> // For mode constants.
#include <time.h>

int numberOfDescriptorsNeeded = 0;
int specialReadPipe = -1;


void setEnvVar(int a, char *s) {
    char buffer[sizeof(int)];
    int ret = snprintf(buffer, sizeof buffer, "%d", a);
    if (ret < 0 || ret >= (int)sizeof(buffer))
        fatal("snprintf failed");
    setenv(s, buffer, 1);
}

void createChannels(int *pipe_dsc) {
    for(int i = 0; i < numberOfDescriptorsNeeded; i += 2) {
        ASSERT_SYS_OK(channel(pipe_dsc + i));
        if(specialReadPipe == -1 && pipe_dsc[i] >= firstAllowedPipe) specialReadPipe = pipe_dsc[i];
        // printf("first pipe: %d, second pipe: %d \n", pipe_dsc[i], pipe_dsc[i+1]);
    }
    for(int i = 0; i < numberOfDescriptorsNeeded; i++) {
        if(pipe_dsc[i] < specialReadPipe || pipe_dsc[i] >= numberOfDescriptorsNeeded) {
            // printf("closing unneded pipe %d \n", pipe_dsc[i]);
            ASSERT_SYS_OK(close(pipe_dsc[i]));
        }   
    }
}

void closeChannels(int *pipe_dsc) {
    for(int i = 0; i < numberOfDescriptorsNeeded; i++) {
        if(pipe_dsc[i] >= specialReadPipe && pipe_dsc[i] < numberOfDescriptorsNeeded) {
            ASSERT_SYS_OK(close(pipe_dsc[i]));
        }
    } 
}

// defining main with arguments
int main(int argc, char* argv[])
{
    int size = atoi(argv[1]);
    numberOfDescriptorsNeeded = 2*(size*size + 11 + size);
    for(int i = 20; i < 1024; i++) close(i);
    pid_t pid;
    int pipe_dsc[numberOfDescriptorsNeeded];
    createChannels(pipe_dsc);
    int firstBarierPipe = specialReadPipe + 2 + 2*size*size;
    // printf("firstBarierPipe = %d\n", firstBarierPipe);

    
    setEnvVar(size,"size");
    setEnvVar(numberOfDescriptorsNeeded, "numberOfDescriptorsNeeded");
    setEnvVar(specialReadPipe,"specialReadPipe");
    setEnvVar(specialReadPipe+1,"specialWritePipe");
    setEnvVar(specialReadPipe+2,"firstCommonPipe");
    setEnvVar(firstBarierPipe,"firstBarierPipe");
    // printf("mimpirun firstCommonPipe = %d", specialReadPipe+2);
    
    int rank = 0;

    while(size > 0) {
        
        setEnvVar(rank,"rank");
        
        rank++;
        ASSERT_SYS_OK(pid = fork());
        if (!pid) {
            ASSERT_SYS_OK(execvp(argv[2], &argv[2]));
        }
        size--;
    }
    closeChannels(pipe_dsc);

    // ssize_t wrote = write(specialWritePipe, &data, sizeof(data));
    // ASSERT_SYS_OK(wrote);
    // if (wrote != sizeof(data))
    //     fatal("Wrote less than expected: %zd out of %zu bytes.", wrote, sizeof(data));
    size = atoi(argv[1]);

    for(int i = 0; i < size; i++) {
        ASSERT_SYS_OK(wait(NULL));
    }

    // info x;
    // ssize_t read_len = read(specialReadPipe,&x, sizeof(x));
    // ASSERT_SYS_OK(read_len);
    // if (read_len == 0)
    //     printf("DAD: We read nothing, end-of-file.\n");
    // else
    //     printf("DAD: count: %d, size: %d, size of PID %d \n",  x.count, x.size, sizeof(x.tab)/sizeof(pid_t));
    //     printf("DAD pid 1 = %d, pid 2 = %d\n", x.tab[0], x.tab[1]);
    
    
    return 0;

}