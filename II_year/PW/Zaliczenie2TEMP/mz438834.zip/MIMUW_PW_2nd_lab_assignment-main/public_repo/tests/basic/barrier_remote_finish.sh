#!/bin/bash
set -e
./run_test 1 4 examples_build/barrier_remote_finish
