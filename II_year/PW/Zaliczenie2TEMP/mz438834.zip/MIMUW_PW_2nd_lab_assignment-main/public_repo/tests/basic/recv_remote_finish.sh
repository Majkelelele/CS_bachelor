#!/bin/bash
set -e
./run_test 1 4 examples_build/recv_remote_finish
