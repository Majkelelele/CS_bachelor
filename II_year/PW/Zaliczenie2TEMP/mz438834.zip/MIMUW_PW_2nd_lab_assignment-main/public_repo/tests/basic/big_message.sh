set -x
./run_test 0.4 2 examples_build/big_message
