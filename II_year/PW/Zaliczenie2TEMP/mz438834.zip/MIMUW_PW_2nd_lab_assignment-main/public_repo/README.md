# Second laboratory assignment

This repository contains materials for second laboratory assignment on PW course on MIMUW in 2023.

Assignment description can be found in [assignment.md](assignment.md).