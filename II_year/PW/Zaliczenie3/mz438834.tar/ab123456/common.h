#pragma once

#include <stdint.h>

typedef int64_t Value;
static const Value EMPTY_VALUE = 0;
static const Value TAKEN_VALUE = -1;
